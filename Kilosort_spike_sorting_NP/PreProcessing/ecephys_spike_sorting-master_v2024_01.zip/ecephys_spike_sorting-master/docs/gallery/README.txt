.. _examples-index:

Gallery of Examples
===================


.. _general_examples:

General examples
----------------

General-purpose and introductory examples from the sphinx-gallery
