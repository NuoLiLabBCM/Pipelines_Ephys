document.write("Click the &quot;Related Data&quot; button to display a list of Allen Brain Atlas \
      resources for the species indicated. Please note that the current project is excluded \
      from the list of suggestions. For example, if a &quot;human&quot; link is displayed while viewing \
      human microarray data, it refers to related ISH data. \
	");
