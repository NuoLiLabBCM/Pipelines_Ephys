=====
Usage
=====

To use AIBS ecephys spike sorting in a project::

    import ecephys_spike_sorting
