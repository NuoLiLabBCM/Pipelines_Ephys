======
README
======

.. include:: ../README.md
