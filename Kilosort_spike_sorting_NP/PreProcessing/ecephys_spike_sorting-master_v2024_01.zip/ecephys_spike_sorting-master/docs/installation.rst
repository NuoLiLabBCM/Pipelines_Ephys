.. highlight:: shell

======================================
ecephys spike sorting Installation
======================================

.. code-block:: console

    $ git clone https://github.com/AllenInstitute/ecephys_spike_sorting.git
    $ pip install .

