import pytest
import numpy as np
import os

from ecephys_spike_sorting.modules.extract_from_npx.create_settings_json import create_settings_json
import ecephys_spike_sorting.common.utils as utils

DATA_DIR = os.environ.get('ECEPHYS_SPIKE_SORTING_DATA', False)

def test_extract_from_npx():

	input_xml = os.path.join(DATA_DIR, 'settings.xml')

	oe_json = create_settings_json(input_xml)