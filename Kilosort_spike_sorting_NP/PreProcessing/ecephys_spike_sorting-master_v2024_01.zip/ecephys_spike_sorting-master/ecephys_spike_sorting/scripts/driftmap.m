
function driftmap(ksdir) 
    addpath(genpath('E:\code\ecephys_spike_sorting-master_12142023\setups\spikes-master'))
    % probably dont need to add npy-matlab to path. Should have been added for SpikeGLX pipeline anyway.
    addpath(genpath('E:\code\ecephys_spike_sorting-master_12142023\setups\npy-matlab-master')) 
    % Plotting a driftmap
    [spikeTimes, spikeAmps, spikeDepths, spikeSites] = ksDriftmap(ksdir);
    f = figure('visible', 'off','units','normalized','outerposition',[0 0 1 1]); 
    plotDriftmap(spikeTimes, spikeAmps, spikeDepths);
    %saving driftmap as PNG in ksdir
    saveas(f, strcat(ksdir, '\driftmap_plot.png'))
end